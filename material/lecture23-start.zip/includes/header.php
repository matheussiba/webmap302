    <head>
        <meta charset="UTF-8">
        <title>ImaginaryEnv</title>
        <link rel="stylesheet" href="/<?php echo $root_directory ?>/css/bootstrap.css">
        <link rel="stylesheet" href="/<?php echo $root_directory ?>/css/style.css">
        <script src="/<?php  echo $root_directory?>/resources/jquery.min.js"></script>
        <script src="/<?php  echo $root_directory?>/js/js_functions.js"></script>
    </head>
   