        <div class="container">
            <p class="text-center">&copy; <a href='/<?php  echo $root_directory?>/index.php'>Imaginary Environmental</a> 2018</p>
        </div> <!--Container-->
